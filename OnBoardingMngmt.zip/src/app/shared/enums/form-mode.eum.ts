export enum FormMode {
    ReadOnly = 1, Edit = 2, New = 3
}