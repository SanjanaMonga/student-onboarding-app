export enum StudentType {
    Domestic = 1,
    International = 2
}
