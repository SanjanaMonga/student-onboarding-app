export interface Document {
    name: string;
    mandatory: boolean;
}
