import { Injectable } from '@angular/core';
import { HttpService } from './http.service';
import { Observable } from 'rxjs';
import { Student } from '../models/student';
import { flatMap } from 'rxjs/operators';

@Injectable({
    providedIn: 'root'
})
export class StudentService {

    constructor(private _httpService: HttpService) {
    }

    public getAllStudents(): Observable<Student[]> {
        return this._httpService.get('../assets/student-data.json');
    }
}
