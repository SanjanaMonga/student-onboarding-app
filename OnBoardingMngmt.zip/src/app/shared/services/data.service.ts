// import { Injectable } from '@angular/core';
// import { HttpService } from './http.service';
// import { Subject, BehaviorSubject } from 'rxjs';
// import { Student } from '../models/student';

// @Injectable({
//     providedIn: 'root'
// })
// export class DataService {

//     private studentInfo = new Subject<Student>();
//     private tabChange = new BehaviorSubject<string>('2');

//     studentInfo$ = this.studentInfo.asObservable();
//     tabChange$ = this.tabChange.asObservable();

//     public viewStudentEmitter(student: Student) {
//         this.studentInfo.next(student);
//     }

//     public tabChangeEmitter(tab: string) {
//         this.tabChange.next(tab);
//     }
// }
