import { Observable } from 'rxjs';
import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { catchError } from 'rxjs/operators';

@Injectable({
    providedIn: 'root'
})
export class HelperService {

    constructor() {
    }

    public setItemToLocalStorage(key: string, value: any): void {
        value = JSON.stringify(value);
        localStorage.setItem(key, value);
    }

    public getItemFromLocalStorage(key: string): any {
        const item = localStorage.getItem(key);
        return JSON.parse(item);
    }

    public isLoggedIn(): boolean{
        if (this.getItemFromLocalStorage('user') !== null) {
            return true;
        } else {
            return false;
        }
    }
}
