import { NgModule } from '@angular/core';
import { StudentListComponent } from './student-list/student-list.component';
import { StudentTileComponent } from './student-tile/student-tile.component';
import { CommonModule } from '@angular/common';
import { OnboardRoutingModule } from './onboard-routing.module';
import { OnboardManagementComponent } from './onboard-management.component';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { StudentOnboardingFormComponent } from './student-onboarding-form/student-onboarding-form.component';
import { FontAwesomeModule } from '@fortawesome/angular-fontawesome';
import { FormsModule } from '@angular/forms';

@NgModule({
    declarations: [
        StudentListComponent,
        StudentTileComponent,
        OnboardManagementComponent,
        StudentOnboardingFormComponent
    ],
    imports: [CommonModule, FontAwesomeModule, FormsModule, NgbModule],
    exports: [
        StudentListComponent,
        StudentTileComponent,
        OnboardRoutingModule,
        OnboardManagementComponent,
        StudentOnboardingFormComponent
    ]
})
export class OnboardManagementModule {

}
