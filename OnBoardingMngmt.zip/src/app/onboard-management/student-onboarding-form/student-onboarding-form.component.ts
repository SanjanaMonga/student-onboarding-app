import { Component, OnInit } from '@angular/core';
import { Student } from 'src/app/shared/models/student';
import { FormMode } from 'src/app/shared/enums/form-mode.eum';
import { Form } from '@angular/forms';
import { ActivatedRoute } from '@angular/router';
import { StudentService } from 'src/app/shared/services/student.service';
import { StudentType } from 'src/app/shared/enums/student-type.enum';

@Component({
    selector: 'app-student-onboarding-form',
    templateUrl: './student-onboarding-form.component.html',
    styleUrls: ['./student-onboarding-form.component.scss']
})
export class StudentOnboardingFormComponent {
    public student: Student = {id: 0, name: '', dob: new Date('1990-01-01'), 
    father: '' ,mother: '', lastScore: 0, category: StudentType.Domestic};
    public formMode: FormMode;
    public onboardingForm: Form;
    constructor(private _route: ActivatedRoute, private _studentService: StudentService) {
        this._route.params.subscribe(params => {
            this._studentService.getAllStudents().subscribe((students) => {
                this.student = students.find(stud =>
                    +params['id'] === +stud.id);
            });
            this.formMode = params['mode'];
        });
    }
}
