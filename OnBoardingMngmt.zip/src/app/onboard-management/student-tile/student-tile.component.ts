import { Component, Input } from '@angular/core';
import { Student } from 'src/app/shared/models/student';
import { faTrash, faPen, faEye } from '@fortawesome/free-solid-svg-icons';
import { StudentType } from 'src/app/shared/enums/student-type.enum';
import { Router } from '@angular/router';
import { FormMode } from 'src/app/shared/enums/form-mode.eum';
// import { DataService } from 'src/app/shared/services/data.service';

@Component({
    selector: 'app-student-tile',
    templateUrl: './student-tile.component.html',
    styleUrls: ['./student-tile.component.scss']
})
export class StudentTileComponent {
    @Input() student: Student;
    public view = faEye;
    public edit = faPen;
    public delete = faTrash;
    public StudentType = StudentType;

    constructor(private _router: Router) {}

    viewStudentOnboaringInfo() {
        // this._dataService.viewStudentEmitter(this.student);
        this._router.navigate(['/form', {id: this.student.id, mode: FormMode.ReadOnly}]) ;
    }

    editStudentOnboaringInfo() {
        this._router.navigate(['/form', {id: this.student.id, mode: FormMode.Edit}]) ;
    }

    deleteStudentOnboaringInfo() {
alert("delete");
    }
}
