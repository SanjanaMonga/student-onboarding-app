import { Component } from '@angular/core';
import { HelperService } from 'src/app/shared/services/helper.service';
import { Router } from '@angular/router';

@Component({
    selector: 'app-login',
    templateUrl: 'login.component.html',
    styleUrls: ['./login.component.scss']
})
export class LoginComponent {
    constructor( private _helperService: HelperService, private _router: Router){}
    login() {
        this._helperService.setItemToLocalStorage('user', {user: 'admin'});
        this._router.navigate(['/list']);
    }
}
